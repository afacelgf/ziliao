<?php
/**
 * Created by PhpStorm.
 * User: Xs___
 * Date: 2019/08/25
 * Time: 09:52
 * Desc:
 */

return [
    //域名
    'base_url' => 'https://hjb.jxpyq666.com/',
    //接口秘钥
    'api_key' => 'acfwDzajc2GBaHazOe',
    //支付设置
    'app_id' => 'wx895d0c0979c8c8f4',
    'secret' => 'e8219ac65e77552aad460af4f87c1899',
    // 微信获取access_token的url地址
    'access_token_url' => "https://api.weixin.qq.com/cgi-bin/token?" . "grant_type=client_credential&appid=%s&secret=%s",
    //发送模板消息url地址
    'sendTemplateMessage_url' => "https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=%s",

    'response_type' => 'array',
    'log' => [
        'level' => 'debug',
        'file' => app()->getRuntimePath() . 'wechat.log',
    ],
    

    'mch_id' => '1574171031',
    'key' => 's4SD8f4a8f4aSDFAS7as7sda4a558sas',
    'cert_path' => app()->getRootPath() . 'cert/apiclient_cert.pem',
    'key_path' => app()->getRootPath() . 'cert/apiclient_key.pem',
    'rootca_path' => app()->getRootPath() . 'cert/rootca.pem',
    'notify_url' => 'http://www.haojiabang520.com/notify',
    'laiguofengopenid' => 'oIJO55dxK351_dvsS6S9sKQhUo-g',
    'managesAccountOpenid' => ['oIJO55dxK351_dvsS6S9sKQhUo-g', 'oIJO55eGYDMlQl5GXbC4vNVmOAQU'], //管理员的账户
    'shopRuzhuTip' => '好消息，平台补贴期间，限时免费入驻了，赶紧来申请吧',//店铺入驻页面的口号
    'kouhaotip' => '关心家乡每日事，就在家乡朋友圈',//我的页面的口号
    'tixianCount' => 182,//已提现成功人数
    'zanjifen' => 10,//赞得积分
    'invitationjifen' => 10, //邀请好友得积分
    'readjifen' => 1,//阅读得积分
    'commentjifen' => 2,//评论得积分
    'kefuwx' => 15778064843,//客服微信号
    'zsphone' => 15778064843,//招商合作电话
    'getjifentip' => '积分可以直接兑换为现金，获取途径：邀请新用户10积分/人，发布新闻后，新闻的浏览量1积分/次、点赞10积分/赞、评论2积分/个，快去邀请用户和发布新闻吧，分享到微信群将获得更多的阅读和点赞喔。',//招商合作电话
    'chatUrl' => "https://laiopenai.openai.azure.com/openai/deployments/laigpt35/chat/completions/?api-version=2023-05-15",
    'chatKey' => 'b3e51b36f90f455ab8ebb2c7dc5d4f69',
    'chatNormalUseCountLimit' => 3,//chat每天次数-普通用户
    'chatVipUseCountLimit' => 50,//chat每天次数-vip
    'chatNormalTextCountLimit' => 50, //chat问题字数限制-普通用户
    'chatVipTextCountLimit' => 1000,//chat问题字数限制-vip
    'chatAnswerShowSpeed' => 70,//chat答案显示的速度
    'chatContextNavTitle' => 'ChatGPT Pro',//chat导航栏
    'chatSingleNavTitle' => 'AI 聊天',//chat导航栏


    'chatContextNavTitleInCheck' => '按钮列表',//chat导航栏检查
    'chatSingleNavTitleInCheck' => '按钮列表',//chat导航栏检查
    'chatColorList'=>[
        [
            'title'=> '嫣红',
            'name'=> 'red',
            'color'=>'#e54d42'
        ],
        [
            'title'=> '桔橙',
            'name'=> 'orange',
            'color'=>'#f37b1d'
        ],
        [
            'title'=> '明黄',
            'name'=> 'yellow',
            'color'=>'#fbbd08'
        ],
    ],

    'xcxIsInCheck'=>0,//是否正在审核

    'ttaKey' => '9a6d14c32ebb4061b03fa0524cc0108d',
    'ttaArea' => 'eastasia',
    'ttaDefaultSpeeckPerson' => 'zh-cn-XiaochenNeural',//tta默认主播
    'ttaNormalUseCountLimit' => 2,//tta每天使用次数-普通用户
    'ttaVipUseCountLimit' => 20,//tta每天使用次数-vip
    'ttaNormalTextCount' => 80, //配音字数限制
    'ttaVipTextCount' => 800, //配音vip字数限制
    'ttaNormalOutputFileCount' => 1, //配音导出文件限制
    'ttaVipOutputFileCount' => 20, //配音vip导出文件限制
    'ttaIpLimitTimes' => 10, //配音同一ip访问限制时间间隔10s
    'ttaUseLimitTip'=>'主人，您今天的次数已用完 \n成为会员可体验更多好用好玩的功能！',
    //配音感情
    'ttaGanqingChineseArr'=> ['默认', '热情而轻松', '闲聊语气', '友好热情', '正式(新闻)', '温暖亲切', '生气', '沉着冷静', '欢快', '轻蔑(抱怨)', '恐惧(紧张)', '悲伤', '严肃'],
    'ttaganqingEnglishArr'=>['general', 'assistant', 'chat', 'customerservice', 'newscast', 'affectionate', 'angry', 'calm', 'cheerful', 'disgruntled', 'fearful',  'sad', 'serious'],
    'ttaSpeeckName'=>'晓辰', //默认配音员
    'ttaSpeeckIcon'=>'https://hjb.jxpyq666.com/ttaSource/icon/pyyicon/5.jpeg', //默认配音员
    'ttaSpeeckRealName'=>'zh-cn-XiaochenNeural',//默认名称


    'xcxOpenAllVipTip'=>'主人，您今天的次数已用完 \n明天再来或者联系客服给您紧急增加次数',
    //关于
    'xcxAbout' => '配音侠是一种基于计算机的语音工具，可以将文本内容转换成语音来进行播报及播放。它将文字信息和音频信息结合起来，使用合成技术，以特定的语音或语调朗读出文字内容，以便实现文字与语音的转换。文字转语音技术主要包括文本分析、语音合成和语音转换三个部分。文本分析是把文本内容分解成一系列的词组和句子，以便于后续的语音合成；语音合成是根据文本分析的结果，使用语音数据库和合成技术，将文本转换成真实的语音；语音转换是将声音信号转换成可以被播放的语音格式。文字转语音技术不仅可以用于播报文字信息，还可以用于制作视频，人机对话系统，智能家居等领域。',
    //新用户提示框
    'xcxNewUserIn' => '新用户送福利了，您将获得3天的高级vip权利！',
    //我的页面vip弹框
    'xcxMineOpenVipTip' => '即日起到2023年12月30日，新会员送福利\n，开一天送一天，开一个月送一个月，开一年送一年\n 邀请新用户进入小程序即可获取相应vip礼包\n快去分享吧',
    'xcxqrcodeTip'=>'截图分享赚取奖励吧',
    'xcxqrcodeTipInCheck'=>'截图分享赚取奖励吧,\n邀请人数越多奖励的vip越久',
    //openai首页跑马灯
    'xcxHomehorseRaceLamp' => '即日起到2023年12月30日，新会员送福利了,开一天送一天，开一个月送一个月，开一年送一年',
    'xcxHomehorseRaceLampInCheck' =>'欢迎光临，赶紧去体验好玩的配音吧',
    'xcxHomegptpic'=>'ttaSource/chatBtn.jpg',
    'xcxHomegptLogo'=>'ttaSource/chatgpt.png',
    //首页轮播图-正式版
    'xcxHomeSwiper' => [
        [
            'id' => 0,
            'url' => 'https://hjb.jxpyq666.com/ttaSource/swiper/openai.png'
        ],
        [
            'id' => 1,
            'url' => 'https://hjb.jxpyq666.com/ttaSource/swiper/aitta.png'
        ]
    ],
    //首页轮播图-审核版
    'xcxHomeSwiperInCheck' => [
    [
            'id' => 1,
            'url' => 'https://hjb.jxpyq666.com/ttaSource/swiper/aitta.png'
        ]
    ],

    'xcxOpenVipTip' => '即日起到2023年11月30日，新会员送福利\n，开一天送一天，开一个月送一个月，开一年送一年',
    //邀请逻辑
    'xcxSharedRule' => [
        [
            'id' => 0,
            'tip' => '邀请3人并试用，获得3天vip',
            'time' => '+3 day',
            'num'=>3,
        ],
        [
            'id' => 1,
            'tip' => '邀请5人并试用，获得1周vip',
            'time' => '+1 week',
            'num'=>5,
        ],
        [
            'id' => 2,
            'tip' => '邀请10人并试用，获得1月vip',
            'time' => '+1 month',
            'num'=>10,
        ],
        [
            'id' => 3,
            'tip' => '邀请20人并试用，获得2月vip',
            'time' => '+2 month',
            'num'=>20,
        ],
        [
            'id' => 4,
            'tip' => '邀请30人并试用，获得3月vip',
            'time' => '+3 month',
            'num'=>30,
        ],
        [
            'id' => 5,
            'tip' => '邀请40人并试用，获得6月vip',
            'time' => '+6 month',
            'num'=>40,
        ],
        [
            'id' => 6,
            'tip' => '邀请50人并试用，获得8月vip',
            'time' => '+8 month',
            'num'=>50,
        ],
        [
            'id' => 7,
            'tip' => '邀请60人并试用，获得12月vip',
            'time' => '+1 year',
            'num'=>60,
        ],
    ],
    //vip页面的温馨提示
    'xcxVipWxts'=>'1.开通方式：请联系客服领取兑换码,兑换会员即可，\n 2.会员开通后不支持退款。\n 3.如兑换后会员不生效，请刷新【我的】右上角刷新按钮，或者联系客服处理；\n 4.如有其他使用问题，或者新的需求请联系我们的客服处理，感谢理解。',
    //邀请页的注意
    'xcxInviteTip'=>'注意：\n01.一经兑换不可退回\n02.邀请用户并试用一次配音就可生效;\n03.分享到群里可快速获得vip奖励喔！',
    //我的页面，四宫格
    'xcxMineFourList'=>[
        [
        'title'=> '联系客服',
        'url'=> '/pages/mine/kefu?type=1',
        'icon'=> 'cuIcon-goodsfavor'
      ],
      [
          'title'=>  '关注公众号',
          'url'=>  '/pages/mine/kefu?type=2',
          'icon'=>  'cuIcon-edit'
      ],
      [
          'title'=>  '卡密激活',
          'url'=>  '/pages/mine/jihuo',
          'icon'=>  'cuIcon-sponsor'
      ],
      [
          'title'=> '兑换记录',
          'url'=>  '/pages/mine/duihuanHistory',
          'icon'=> 'cuIcon-list'
      ],
    ],
    //我的页面，四宫格-审核
    'xcxMineFourListInCheck'=>[
        [
            'title'=> '联系客服',
            'url'=> '/pages/mine/kefu?type=1',
            'icon'=> 'cuIcon-goodsfavor'
        ],
        [
            'title'=>  '关注公众号',
            'url'=>  '/pages/mine/kefu?type=2',
            'icon'=>  'cuIcon-edit'
        ]
    ],
    //我的界面-问题列表
    'xcxMineProblemList'=>[
      ['index'=>0,'question'=>"1.购买了会员还是显示非会员？","answer"=>"在【我的】右上角点击刷新按钮"],
      ['index'=>1,'question'=>"2.为什么生成配音会失败？","answer"=>"检测是否存在特殊字符，例如%，￥《#等，把他们去掉"],
      ['index'=>2,'question'=>"3.怎么生成的配音文件或者试听没有声音？","answer"=>"检测是否手机开启了静音模式,关闭后重试"]
    ],
    //我的界面-问题列表-审核
    'xcxMineProblemListInCheck'=>[
        ['index'=>0,'question'=>"0.为什么生成配音会失败？","answer"=>"检测是否存在特殊字符，例如%，￥《#等，把他们去掉"],
        ['index'=>1,'question'=>"1.怎么生成的配音文件或者试听没有声音？","answer"=>"检测是否手机开启了静音模式,关闭后重试"]
    ],


];
