<?php

namespace app\ziliao\controller;
use app\admin\model\SongSheet;
use app\Utitls;
use think\facade\Request;
use function app\api\controller\db;

class Ziliao
{
    //年级列表
     public function grades()
    {
        $params = Request::param();
        $res = SongSheet::where(['status' => 1])->order('id desc')->select();
        if ($res) {
            Utitls::sendJson(200,$res);
        }
        Utitls::sendJson(500);
    }

    //根据年级获取对应的科目列表
      public function collectList()
    {
        $params = Request::param();
        $res = db('music')->where(['status' => 1,'collect'=>1])->order('id desc')->select();
        if ($res) {
            Utitls::sendJson(200,$res);
        }
        Utitls::sendJson(500);
    }

    //资料列表-根据年级id和科目id获取对应的资料分类列表【语文、数学】，每个分类下面都有资料列表
     public function songList()
    {
        $params = Request::param();
        $res = db('music')->where(['status' => 1,'gedan_id'=>$params['gedan_id']])->order('sort desc')->select();
        if ($res) {
            Utitls::sendJson(200,$res);
        }
        Utitls::sendJson(500);
    }


}