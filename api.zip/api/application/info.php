

<?php echo phpinfo(); ?>
