<?php
/**
 * Created by PhpStorm.
 * User: Xs___
 * Date: 2019/11/27
 * Time: 22:56:21
 * Desc:
 */

namespace app\admin\controller;

use app\Utitls;
use think\facade\Request;

class Index
{
    public function test()
    {
        print_r('2=====1');
    }


}
